from django.contrib import admin

from .models import UserDetail

admin.site.register(UserDetail)